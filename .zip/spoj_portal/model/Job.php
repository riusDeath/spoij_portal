<?php 

class Job {
	public $fillable = ["storage", 
						"payload", 
						"contestid",
						'lanuage',
						"attempts", 
						"reserved_at", 
						"available_at", 
						"created_at"];

	public $table = "jobs";
}

?>