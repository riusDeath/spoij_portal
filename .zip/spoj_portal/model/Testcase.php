<?php 

class testcase {
	public $fillable = ["contestid", 
					"input", 
					"output", 
					"status"];

	public $table = "testcase";

}

?>
