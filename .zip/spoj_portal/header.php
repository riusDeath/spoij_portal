<?php 
require_once('config.php');
require_once('config/lib/dblib.php');
require_once('config/combine/uploadfile.php');
require_once('config/combine/config.php');
?>
<script src="assert/js/jquery.js"></script>