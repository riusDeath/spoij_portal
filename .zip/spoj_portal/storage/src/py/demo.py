def add(a, b):
	print(float(a)+float(b))

if __name__ == '__main__':
   import sys
   (add(sys.argv[1], sys.argv[2]))
