<?php 
function add ($a, $b){
	return ($a + $b);
}




function main($a, $b) {
    return add($a , $b);
    // $user = { "name":"John", "age":30, "car":null }
    // echo demoObject($user);
    // return implode(" ", SelectionSortAscending($array));
    // return getString($array);
    // return regexEmail($array, $a);
}

?>
