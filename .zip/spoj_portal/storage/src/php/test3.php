<?php 

function getString($string) {
    return $string;
}


?>