<?php 
function add ($a, $b){
	return ($a + $b);
}

function main($a, $b) {
    return add($a , $b);

}

?>
