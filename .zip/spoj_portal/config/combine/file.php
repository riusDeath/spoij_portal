<?php 

function readFile($path) {
	$fp = @fopen($path_test, "r");
	$array_input[] = "";
	$result = '';
	if (!$fp) {
	    return false;
	} else {
	     while(!feof($fp))
	    {
	    	$result .= fgetc($fp).trim();
	    }
	}
	fclose($fp);

	return $result;
}

function writeFile($path_result) {
	chmod($path_result, 0777);
	$fresult = @fopen($path_result, "w+");
	if (!$fresult) {
	    return false ;
	} else {
	    fwrite($fresult, $result);
	}
	fclose($fresult);

	return true;
}

function compareResult($path_result, $path_output) {
	if (filesize($path_result) !== filesize($path_output)) {
		return false;
	}
	$fpout = file($path_output);
	$fresults = file($path_result) ;
	if (($fpout <=> $fresults) != 0) {
		return false;
	}
	fclose($fpout);
	fclose($fresults);
	
	return true ;
}

?>
