<?php 
function compilePython($path, $params) {
	chmod($path, 0777);
	$cmd = "python ".$path." ".$params."";
	echo $cmd;
	return shell_exec($cmd);
}

function compileJava($path, $params, $class) {
	chmod($path, 0777);
	shell_exec("cd ../storage/src/java/");
	$cmd = "java ".$class." ".$params."";
	echo $cmd."<br>";
	return shell_exec($cmd);
}

function compilePHP($path, $params) {
	chmod($path, 0777);
	$cmd = "php -r \"require '".$path."'; echo main(".$params.");\"";
	return shell_exec($cmd);
}

function compileCCC($path, $params) {
	chmod($path, 0777);
	// $cmd = "g++ ".$path." ";
	// return shell_exec($cmd);
}

function combineCode($path, $params, $language, $class) {
	switch ($language) {
		case "php":
			return compilePHP($path, $params);
		case "java":
			return compileJava($path, $params, $class);
		case "py":
			return compilePython($path, $params);
		default:
			// return  compileCCC($path, $params);
			break;
	}
}

?>
