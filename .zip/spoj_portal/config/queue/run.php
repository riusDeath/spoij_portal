<?php 

$queue = new SplQueue();
$queue->enqueue('dev'); 
$queue->enqueue('.to'); 
$queue->rewind();
echo "count".$queue->count()."<br>"; // (int) 2
if ($queue->isEmpty()) {
	echo "empty <br>";
} else {
	echo "not empty<br>";
} 

while($queue->valid()){
    echo $queue->current()."\n"; // Show the first one
    $queue->next(); // move the cursor to the next element
}

?>